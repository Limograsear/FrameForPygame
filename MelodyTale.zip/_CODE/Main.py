import pygame, sys, time, random
import Function
import pygame.locals
from Class import Screen
import Prefab
from UI import LifeDisplayer,BagUI,ExpStatus,SkillUI
from Prefab import PrefabSummoner,Border_Hor, Border_Ver, PTCSummoner, ITEMDICT
import Map

pygame.init()
pygame.mouse.set_visible(False)
font = pygame.font.Font(None, 36)
objList = []
particleList = []
screenCreater = Screen(1280, 720)
screen = screenCreater.CreateScreen()
pygame.display.set_caption("Melody Tale")
pygame.display.set_icon(pygame.image.load("IMAGE/MelodyTale_ICON.png").convert_alpha())
screen.fill("cyan")
# Volume = pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_Volume.png").convert_alpha(),(1440,720))



BackgroundBase = Prefab.bgBase("", screenCreater, objList, particleList)
BackgroundIMG = Prefab.bg1("", screenCreater, objList, particleList)
clock = pygame.time.Clock()
runningTime = pygame.time.get_ticks()
dt = 0



s = Map.Secnery("",screenCreater,objList,particleList,BackgroundBase,BackgroundIMG)#???
s.LoadScenery()
cursor = pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_Cursor.png").convert_alpha(),(64,64))
bord1 = Border_Hor("",screenCreater,objList, particleList, pygame.Vector2(0, -100))
bord2 = Border_Ver("",screenCreater,objList, particleList, pygame.Vector2(-100, 0))
bord3 = Border_Hor("",screenCreater,objList, particleList, pygame.Vector2(0, 1440))
bord4 = Border_Ver("",screenCreater,objList, particleList, pygame.Vector2(1560, 0))
coin = 0
objList.append(bord1)
objList.append(bord2)
objList.append(bord3)
objList.append(bord4)
BackgroundBase.OnEnable()
BackgroundIMG.OnEnable()
test = Prefab.MainCharacter("",screenCreater, objList, particleList)
PartS = PTCSummoner("",screenCreater,objList,particleList)


objList.append(BackgroundIMG)
objList.append(PartS)
objList.append(test)

# rock1 = Prefab.Rock("",screenCreater, objList, particleList, pygame.Vector2(1000, 200))
# objList.append(rock1)
summoner = PrefabSummoner(screenCreater, objList, particleList)

summoner.SummonTile(2,1000,300)
for objs in objList:
    objs.OnEnable()
for PTCs in particleList:
    PTCs.OnEnable()
lifeLine = LifeDisplayer(screenCreater,test)
BagUIins = BagUI(screenCreater,test)
ExpLine = ExpStatus(screenCreater,test)
skliiList = SkillUI(screenCreater,test)
textList = []
for i in range(100):
    textList.append(None)
summoner.SummonWeapon(1, 100, 500)
summoner.SummonWeapon(0, 400, 500)

summoner.SummonCreature(1, 1000, 200)
summoner.SummonCreature(1, 0, 200)
while True:
    screen.fill("cyan")
    objList.sort(key = lambda y:y.pos.y)
    BackgroundBase.Update(dt, runningTime)
    # if Function.RateAct(1) and Function.RateAct(15):
    #     summoner.SummonCreature(1, random.randint(100,900), random.randint(100,900))
    # s.UpdateScenery(dt,runningTime)
    for objs in objList:
        objs.Update(dt, runningTime)
        # try:
        #     pygame.draw.rect(screen, "red", objs.data["Collision"]["rect"], 2)
        # except:
        #     pass
    for PTCs in particleList:
        PTCs.Update(dt,runningTime)
    # screen.blit(Volume,(-60,10))
    lifeLine.DisplayUI()
    for texts in textList:
        if texts == None:
            texts = font.render("Level: "+ str(test.level) + (" Bard" if test.level <= 3 else (" Ovate" if test.level <= 6 else " Druid")), False, (255, 255, 255), (0, 0, 0))
            screen.blit(texts, texts.get_rect(topleft = (0, 10)))
    BagUIins.DisplayUI(pygame.Rect(pygame.mouse.get_pos()[0] + 27, pygame.mouse.get_pos()[1] + 27, 10, 10))
    ExpLine.DisplayUI()
    skliiList.DisplayUI(pygame.Rect(pygame.mouse.get_pos()[0] + 27, pygame.mouse.get_pos()[1] + 27, 10, 10), runningTime)
    if pygame.mouse.get_pos()[0] > 0 and pygame.mouse.get_pos()[1] > 0:
        screen.blit(cursor, pygame.mouse.get_pos())
        # print(pygame.mouse.get_pos())
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    pygame.display.flip()
    dt = clock.tick(60) / 1000
    runningTime = pygame.time.get_ticks()