import random

def RateAct(rate):
    if rate >= random.randint(1,100):
        return True
    else:
        return False
def Distance(a, b):
    return ((a.x - b.x)**2 + (a.y - b.y)**2)**.5