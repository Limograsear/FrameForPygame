from Class import Background, Animal, Player, MeleeWeapon, Tile, DistantWeapon, Bullet, Skill, Weapon, Creature, GameObject, Particle
import pygame, random, Function, math

class Border_Hor(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[False,True,True,False,False,False,False,False,False]):
        image_file = "IMAGE/MelodyTale_Empty.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.pos = SummonLocation
        
    def Update(self, DT, runningTime):
        self.data["Collision"]["rect"] = pygame.Rect(self.data["Collision"]["rect"].x, self.data["Collision"]["rect"].y, 1560, self.data["Collision"]["rect"].h)
        
        if self.data["Barrier"]["barrierAble"]:
            if self.CPNs["Barrier"] and self.CPNs["Collision"]:
                for objs in self.objList:
                    if issubclass(objs.__class__, Player):
                        pass
                    try:
                        if self.data["Collision"]["rect"].colliderect(objs.data["Collision"]["rect"]) and objs != self and objs.CPNs["Move"]:
                            if not issubclass(objs.__class__, Player):
                                objs.pos.x += objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                objs.pos.y += objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                            else:
                                self.image.copy().fill((255,255,255,255))
                                for o in self.objList:
                                    if objs != o:
                                        if abs(self.pos.x - objs.pos.x) >= 1510:
                                            o.pos.x -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                        if abs(self.pos.y - objs.pos.y) >= 25:
                                            o.pos.y -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                                for o in self.PTCList:
                                    if objs != o:
                                        if abs(self.pos.x - objs.pos.x) >= 1510:
                                            o.particalPattern["Transform"]["pos"].x -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                        if abs(self.pos.y - objs.pos.y) >= 25:
                                            o.particalPattern["Transform"]["pos"].y -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                    except:
                        pass
        return super().Update(DT, runningTime)
class Border_Ver(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[False,True,True,False,False,False,False,False,False]):
        image_file = "IMAGE/MelodyTale_Empty.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.pos = SummonLocation
        
    def Update(self, DT, runningTime):
        self.data["Collision"]["rect"] = pygame.Rect(self.data["Collision"]["rect"].x, self.data["Collision"]["rect"].y, self.data["Collision"]["rect"].w, 1440)
        
        if self.data["Barrier"]["barrierAble"]:
            if self.CPNs["Barrier"] and self.CPNs["Collision"]:
                for objs in self.objList:
                    if issubclass(objs.__class__, Player):
                        pass
                    try:
                        if self.data["Collision"]["rect"].colliderect(objs.data["Collision"]["rect"]) and objs != self and objs.CPNs["Move"]:
                            if not issubclass(objs.__class__, Player):
                                objs.pos.x += objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                objs.pos.y += objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                            else:
                                self.image.copy().fill((255,255,255,255))
                                for o in self.objList:
                                    if objs != o:
                                        if abs(self.pos.x - objs.pos.x) >= 50:
                                            o.pos.x -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                        if abs(self.pos.y - objs.pos.y) >= 1440:
                                            o.pos.y -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                                for o in self.PTCList:
                                    if objs != o:
                                        if abs(self.pos.x - objs.pos.x) >= 50:
                                            o.particalPattern["Transform"]["pos"].x -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                        if abs(self.pos.y - objs.pos.y) >= 1440:
                                            o.particalPattern["Transform"]["pos"].y -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                    except:
                        pass
        return super().Update(DT, runningTime)
class bg1(Background):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        image_file = "IMAGE/MelodyTale_bg1.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 1560
        self.data["SetImage"]["scale"]["y"] = 1440
class bgBase(Background):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        image_file = "IMAGE/MelodyTale_bg_Base.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 1560 
        self.data["SetImage"]["scale"]["y"] = 1440
        self.offset = 0
    def Update(self, DT, runningTime):
        self.offset = 100*math.sin(runningTime/1000) - 100
        for objs in self.objList:
                if issubclass(objs.__class__, Player):
                    self.pos = pygame.Vector2(objs.data["Collision"]["rect"].x + 50 - self.image.get_width()/2, objs.data["Collision"]["rect"].y + 50 - self.image.get_height()/2)
                    break
        self.screen.screen.blit(pygame.transform.scale(self.image, (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])), pygame.Vector2(self.offset,self.offset * .6))

class EnemyBloodLine(Background):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[]):
        image_file = "IMAGE/MelodyTale_EnemyBloodLine.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.pos = SummonLocation
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
class EnemyBloodLine_Filled(Background):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[]):
        image_file = "IMAGE/MelodyTale_EnemyBloodLine_Filled.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.pos = SummonLocation
        self.length = 1
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
    def Update(self, DT, runningTime):
        if self.length > (self.data["Parent"].data["Health"]["currentHealth"]/self.data["Parent"].data["Health"]["maxHealth"]):
            self.length -= .02
        elif self.length < (self.data["Parent"].data["Health"]["currentHealth"]/self.data["Parent"].data["Health"]["maxHealth"]):
            self.length += .02
        self.data["SetImage"]["scale"]["x"] = 100 * self.length
        return super().Update(DT, runningTime)
    
class MainCharacter(Player):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[True, True, False, True, True, False, True, True, False]):
        image_file = "IMAGE/MelodyTale_MainCharacter.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Anchor"]["ext"][0] = pygame.Vector2(50,0)
        self.itemDict = ITEMDICT
        self.weapon_buffer = ""
        # self.data["Child"]["obj"].append(Saber)
        self.data["Health"]["maxHealth"] = 3
        self.data["Health"]["currentHealth"] = 3
        self.equipment = {"weapon":"", "musicscore":""}
        self.skillCPN = {"currentSkill":0, "skillScoreList":0, "skillCooldownTime":[10,5,5,5], "skillUseTime":[-1,-1,-1,-1]}
        self.data["Health"]["bloodDisplay"] = False
        try:
            self.data["Child"]["obj"].append(ITEMDICT["item"][self.equipment["weapon"]])
        except:
            pass
        self.bag = []
    def UseSkill(self, now):
        if self.CPNs["InputController"]:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_1] and (self.skillCPN["skillUseTime"][0] < 0 or now - self.skillCPN["skillUseTime"][0] > self.skillCPN["skillCooldownTime"][0] * 1000):
                self.skillCPN["currentSkill"] = 1
                self.equipment["weapon"] = "Harp";
            if keys[pygame.K_2] and (self.skillCPN["skillUseTime"][1] < 0 or now - self.skillCPN["skillUseTime"][1] > self.skillCPN["skillCooldownTime"][1] * 1000):
                self.skillCPN["currentSkill"] = 2
                self.equipment["weapon"] = "Harp";
            if keys[pygame.K_3] and (self.skillCPN["skillUseTime"][2] < 0 or now - self.skillCPN["skillUseTime"][2] > self.skillCPN["skillCooldownTime"][2] * 1000):
                self.skillCPN["currentSkill"] = 3
                self.equipment["weapon"] = "Harp";
            if keys[pygame.K_ESCAPE]:
                self.skillCPN["currentSkill"] = 0
    def OnEnable(self, imageFileList=["IMAGE/MelodyTale_MainCharacter_Idle.png","IMAGE/MelodyTale_MainCharacter_Walk.png","IMAGE/MelodyTale_MainCharacter_Death.png"]):
        return super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)
        if self.equipment["weapon"] != "Harp":
            self.weapon_buffer = self.equipment["weapon"]
        self.UseSkill(runningTime)
        if self.data["Child"]["obj"] == [] or self.equipment["weapon"] != type(self.data["Child"]["obj"][0]).__name__:
            if self.data["Child"]["obj"] != []:
                self.objList.remove(self.data["Child"]["obj"][0])
                self.data["Child"]["obj"] = []
            if self.equipment["weapon"] != "":
                newChild = ITEMDICT["item"][self.equipment["weapon"]]("", self.screen, self.objList, self.PTCList, self.pos.copy())
                newChild.OnEnable()
                self.data["Child"]["obj"].append(newChild)
                self.objList.append(newChild)
                newChild.data["Parent"] = self
        
    def PickItem(self):
        if (len(self.bag) < 24 or (self.equipment["weapon"] == "")) and self.CPNs["Collision"] and self.CPNs["InputController"]:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_e]:
                for objs in self.objList:
                    if (not (issubclass(objs.__class__, Particle) or issubclass(objs.__class__, PTCSummoner))):
                        if objs.CPNs["Item"] and objs.data["Item"]["pickable"] and objs.data["Parent"] == None:
                            if self.data["Collision"]["rect"].colliderect(objs.data["Collision"]["rect"]) and objs != self:
                                if len(self.bag) < 24 or self.equipment["weapon"] == "":
                                    self.objList.remove(objs)
                                    if issubclass(objs.__class__, Weapon) and self.data["Child"]["obj"] == []:
                                            self.equipment["weapon"] = type(objs).__name__
                                            break
                                    else:
                                        self.bag.append(type(objs).__name__)
    def QuitItem(self):
        if self.CPNs["InputController"]:
            keys = pygame.key.get_pressed()
            try:
                if keys[pygame.K_q] and issubclass(self.data["Child"]["obj"][0].__class__, Weapon) and type(self.data["Child"]["obj"][0]).__name__ != "Harp":
                    child = self.data["Child"]["obj"][0]
                    child.data["Parent"] = None
                    self.data["Child"]["obj"].remove(child)
                    self.equipment["weapon"] = ""
            except:
                pass

class Sheep(Animal):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[False, True, False, True, False, True, True, False, False]):
        image_file = "IMAGE/Sheep.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Anchor"]["ext"][0] = pygame.Vector2(0,-45)
        self.data["Anchor"]["ext"].append(pygame.Vector2(0,-45))
        self.data["Health"]["camp"] = 1
        self.data["Health"]["maxHealth"] = 5
        self.data["Health"]["currentHealth"] = 5
        self.pos = SummonLocation
        self.data["Child"]["obj"].append(EnemyBloodLine)
        self.data["Child"]["obj"].append(EnemyBloodLine_Filled)
    
    def OnDisable(self):
        for objs in self.objList:
            if type(objs) == MainCharacter:
                objs.exp += 90
                break
        return super().OnDisable()
    def Update(self, DT, runningTime):
        
        return super().Update(DT, runningTime)
    def Move(self, DeltaTime):
        for objs in self.objList:
            if issubclass(objs.__class__, Player) and Function.Distance(self.pos, objs.pos) <= 300:
                    if self.pos.x > objs.pos.x:
                        self.data["Move"]["moveDir"].x = -.5
                    elif self.pos.x < objs.pos.x:
                        self.data["Move"]["moveDir"].x = .5
                    if self.pos.y > objs.pos.y:
                        self.data["Move"]["moveDir"].y = -1
                    elif self.pos.y < objs.pos.y:
                        self.data["Move"]["moveDir"].y = 1
                    break
            else:
                if ((self.data["Move"]["moveDir"].x ** 2 + self.data["Move"]["moveDir"].y ** 2) ** .5) != 0:
                    self.data["Move"]["moveDir"] = self.data["Move"]["moveDir"] if Function.RateAct(96) else pygame.Vector2(0,0)
                else:
                    if Function.RateAct(10):
                        self.data["Move"]["moveDir"] = pygame.Vector2(random.randint(-1, 1), random.randint(-1, 1))
class Ghost(Animal):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[True, True, False, True, True, True, True, False, False]):
        image_file = "IMAGE/MelodyTale_Ghost.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Anchor"]["ext"][0] = pygame.Vector2(0,-45)
        self.data["Anchor"]["ext"].append(pygame.Vector2(0,-45))
        self.data["Health"]["camp"] = 1
        self.data["Health"]["maxHealth"] = 5
        self.data["Health"]["currentHealth"] = 5
        self.pos = SummonLocation
        self.data["Child"]["obj"].append(EnemyBloodLine)
        self.data["Child"]["obj"].append(EnemyBloodLine_Filled)
        self.data["Health"]["bloodDisplay"] = False
    def OnEnable(self, imageFileList=["IMAGE/MelodyTale_Ghost_Idle.png"]):
        return super().OnEnable(imageFileList)
    def OnDisable(self):
        for objs in self.objList:
            if type(objs) == MainCharacter and self.data["Health"]["camp"] != objs.data["Health"]["camp"]:
                self.data["Health"]["camp"] = 0
                objs.exp += 1000
                break
        return super().OnDisable()
    def Update(self, DT, runningTime):
        self.AnimateOneFrame()
        if Function.RateAct(10):
            self.SummonPTCs(2,self,random.randint(16,48),random.randint(0,360),pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),5,2)
        return super().Update(DT, runningTime)
    def Move(self, DeltaTime):
        if self.CPNs["Move"]:
            for objs in self.objList:
                if issubclass(objs.__class__, Creature):
                    if ((objs.data["Health"]["camp"] == 0 and (2 not in self.BuffCPN["buffList"])) or (objs.data["Health"]["camp"] == 1 and objs != self and (2 in self.BuffCPN["buffList"]))) and Function.Distance(self.pos, objs.pos) <= 500:
                            if self.pos.x > objs.pos.x:
                                self.data["Move"]["moveDir"].x = -.5
                            elif self.pos.x < objs.pos.x:
                                self.data["Move"]["moveDir"].x = .5
                            if self.pos.y > objs.pos.y:
                                self.data["Move"]["moveDir"].y = -.5
                            elif self.pos.y < objs.pos.y:
                                self.data["Move"]["moveDir"].y = .5
                            break
                    else:
                        if ((self.data["Move"]["moveDir"].x ** 2 + self.data["Move"]["moveDir"].y ** 2) ** .5) != 0:
                            self.data["Move"]["moveDir"] = self.data["Move"]["moveDir"] if Function.RateAct(96) else pygame.Vector2(0,0)
                        else:
                            if Function.RateAct(20):
                                self.data["Move"]["moveDir"] = pygame.Vector2(random.randint(-1, 1), random.randint(-1, 1))
        else:
            self.data["Move"]["moveDir"] = pygame.Vector2(0,0)
    
class Saber(MeleeWeapon):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[True,True,False,False,True,True,False, False, True]):
        image_file = "IMAGE/MelodyTale_Saber.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Attack"]["damage"] = 5
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation
        self.coolDownTime = 1000
    def OnEnable(self, imageFileList=["IMAGE/MelodyTale_Saber.png", "IMAGE/MelodyTale_Saber_Attack.png"]):
        return super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        if Function.RateAct(10) and self.data["Parent"] == None:
            self.SummonPTCs(0,self,random.randint(16,32),random.randint(0,360),pygame.Vector2(random.randint(-100,100), random.randint(-100,100)),random.randint(300, 700),5,0)
        super().Update(DT, runningTime)
    def Attack(self, now):
        for i in range(5):
            self.SummonPTCs(0,self,random.randint(16, 32),random.randint(0,360),pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),5,1)
        return super().Attack(now)
class Rock(Tile):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[False,True,True,False,False,False,False,False,False]):
        image_file = "IMAGE/MelodyTale_Rock.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Barrier"]["barrierAble"] = True
        self.pos = SummonLocation
class Tree_0_top(Tile):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[False,True,True,False,False,False,False,False,False]):
        image_file = "IMAGE/MelodyTale_Tree_0_top.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Barrier"]["barrierAble"] = False
        self.pos = SummonLocation
class Tree_0_bot(Tile):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening=[False,True,True,False,False,False,False,False,False]):
        image_file = "IMAGE/MelodyTale_Tree_0_bot.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["Barrier"]["barrierAble"] = True
        self.pos = SummonLocation
        self.data["Anchor"]["ext"][0] = pygame.Vector2(0,-100)
        


class OakWoodBow(DistantWeapon):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening = [True,True,False,False,True,True,False, False, True]):
        image_file = "IMAGE/MelodyTale_OakWoodBow.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        # self.data["Attack"]["damage"] = 5 Invalid
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation
        self.coolDownTime = 1000
    def OnEnable(self, imageFileList=["IMAGE/MelodyTale_OakWoodBow.png","IMAGE/MelodyTale_OakWoodBow_Winding.png"]):
        return super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        if Function.RateAct(10) and self.data["Parent"] == None:
            self.SummonPTCs(1,self,random.randint(16,32),random.randint(0,360),pygame.Vector2(random.randint(-100,100), random.randint(-100,100)),random.randint(300, 700),5,0)
        try:
            if self.data["SetImage"]["displaying"] == int(len(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]]) * (1 / self.data["Animate"]["animationSpeed"])) - 1 and self.data["SetImage"]["using"] == 1:
                if self.data["Parent"] != None:
                    PrefabSummoner(self.screen, self.objList, self.PTCList).SummonBullet(0, self.data["Parent"].pos.copy(), -1*self.data["Parent"].data["Anchor"]["rotate"])
                    self.data["SetImage"]["using"] = 0
        except:
            pass
        return super().Update(DT, runningTime)
    def Attack(self, now):
        self.data["SetImage"]["using"] = 1
        
class Harp(DistantWeapon):#Valid only when using skills
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation, CPNisOpening = [True,True,False,False,True,True,False, False, True]):
        image_file = "IMAGE/MelodyTale_Harp.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        # self.data["Attack"]["damage"] = 5 Invalid
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation #Maybe valid??
        # self.coolDownTime = 1000
        
    def OnEnable(self, imageFileList=["IMAGE/MelodyTale_Harp.png", "IMAGE/MelodyTale_Harp.png"]):
        return super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        if self.data["Parent"] != None:
            if self.data["Parent"].skillCPN["currentSkill"] == 0:
                self.data["Parent"].equipment["weapon"] = self.data["Parent"].weapon_buffer
        if Function.RateAct(10) and self.data["Parent"] == None:
            self.SummonPTCs(1,self,random.randint(16,32),random.randint(0,360),pygame.Vector2(random.randint(-100,100), random.randint(-100,100)),random.randint(300, 700),5,0)
        try:
            if self.data["SetImage"]["displaying"] == int(len(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]]) * (1 / self.data["Animate"]["animationSpeed"])) - 1 and self.data["SetImage"]["using"] == 1:
                if self.data["Parent"] != None:
                    if self.data["Parent"].skillCPN["currentSkill"] == 1:
                        self.data["Parent"].skillCPN["skillUseTime"][0] = runningTime
                        PrefabSummoner(self.screen, self.objList, self.PTCList).SummonBullet(1, self.data["Parent"].pos.copy(), -1*self.data["Parent"].data["Anchor"]["rotate"])
                        
                    elif self.data["Parent"].skillCPN["currentSkill"] == 2:
                        self.data["Parent"].skillCPN["skillUseTime"][1] = runningTime
                        PrefabSummoner(self.screen, self.objList, self.PTCList).SummonBullet(2, self.data["Parent"].pos.copy(), -1*self.data["Parent"].data["Anchor"]["rotate"])
                        
                    elif self.data["Parent"].skillCPN["currentSkill"] == 3:
                        self.data["Parent"].skillCPN["skillUseTime"][2] = runningTime
                        PrefabSummoner(self.screen, self.objList, self.PTCList).SummonBullet(3, self.data["Parent"].pos.copy(), -1*self.data["Parent"].data["Anchor"]["rotate"])
                    self.data["SetImage"]["using"] = 0
                    self.data["Parent"].skillCPN["currentSkill"] = 0
        except:
            pass
        return super().Update(DT, runningTime)
    def Attack(self, now):
        self.data["SetImage"]["using"] = 1



        
class Arrow0(Bullet):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation,CPNisOpening=[False, True, False, True, False, True, False, False, False]):
        image_file = "IMAGE/MelodyTale_Arrow0.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
        self.data["Move"]["moveSpeed"] = 2400
        self.data["Attack"]["damage"] = 2
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation
        
    def Attack(self, now):
        t = self.data["Attack"]["timeAttack"]
        super().Attack(now)
        if self.data["Attack"]["timeAttack"] != t:
            self.OnDisable()
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)
    def OnDisable(self):
        return super().OnDisable()

class Skill_1(Skill):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation,CPNisOpening=[False, True, False, True, False, True, False, False, False]):
        image_file = "IMAGE/MelodyTale_Empty.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
        self.data["Move"]["moveSpeed"] = 2400
        
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation
        self.deathPos = pygame.Vector2(-1000,0)
        
    def Attack(self, now):
        t = self.data["Attack"]["timeAttack"]
        super().Attack(now)
        if self.data["Attack"]["timeAttack"] != t:
            self.OnDisable()
    def Update(self, DT, runningTime):
        if self.deathPos.x == -1000:
            self.deathPos = pygame.Vector2(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
        if Function.Distance(self.pos, self.deathPos) <= 50:
            self.OnDisable()
        for i in range(random.randint(3,6)):
            self.SummonPTCs(1,self,random.randint(16,32),random.randint(0,360),pygame.Vector2(random.randint(-25,25), random.randint(-25,25)),random.randint(300, 700),5,0)
        super().Update(DT, runningTime)
    def OnDisable(self):
        for i in range(100):
                self.SummonPTCs(1,self,random.randint(16,48),random.randint(0,360),pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),5,2)
        for i in range(-180,0):
                self.SummonPTCs(1,self,random.randint(32,48),random.randint(0,360),pygame.Vector2(0 + 100 * math.cos(math.radians(i)) + random.randint(-5,5),  (100 / (3**.5)) + 100 * math.sin(math.radians(i)) + random.randint(-5,5)),random.randint(300, 700),5,1)
        for i in range(-60, 120):
                self.SummonPTCs(1,self,random.randint(32,48),random.randint(0,360),pygame.Vector2(-50 + 100 * math.cos(math.radians(i)) + random.randint(-5,5), - (50 / (3**.5)) + 100 * math.sin(math.radians(i)) + random.randint(-5,5)),random.randint(300, 700),5,1)
        for i in range(60, 240):
                self.SummonPTCs(1,self,random.randint(32,48),random.randint(0,360),pygame.Vector2(50 + 100 * math.cos(math.radians(i)) + random.randint(-5,5), - (50 / (3**.5)) + 100 * math.sin(math.radians(i)) + random.randint(-5,5)),random.randint(300, 700),5,1)
        return super().OnDisable()

class Skill_2(Skill):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation,CPNisOpening=[False, True, False, True, False, True, False, False, False]):
        image_file = "IMAGE/MelodyTale_Empty.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
        self.data["Move"]["moveSpeed"] = 2400
        self.SetBuffCPN["buffCode"] = 1
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation
        self.deathPos = pygame.Vector2(-1000,0)
        
    def Attack(self, now):
        t = self.data["Attack"]["timeAttack"]
        super().Attack(now)
        if self.data["Attack"]["timeAttack"] != t:
            self.OnDisable()
    def Update(self, DT, runningTime):
        if self.deathPos.x == -1000:
            self.deathPos = pygame.Vector2(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
        if Function.Distance(self.pos, self.deathPos) <= 50:
            self.OnDisable()
        for i in range(random.randint(3,6)):
            self.SummonPTCs(5,self,random.randint(16,32),0,pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),0,0)
        super().Update(DT, runningTime)
    def OnDisable(self):
        for i in range(100):
                self.SummonPTCs(5,self,random.randint(32,48),random.randint(0,360),pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),5,2)
        
        return super().OnDisable()

class Skill_3(Skill):
    def __init__(self, image_file, screen, objList, PTCList, SummonLocation,CPNisOpening=[False, True, False, True, False, True, False, False, False]):
        image_file = "IMAGE/MelodyTale_Empty.png"
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
        self.data["Move"]["moveSpeed"] = 2400
        self.SetBuffCPN["buffCode"] = 2
        self.data["Health"]["camp"] = 0
        self.pos = SummonLocation
        self.deathPos = pygame.Vector2(-1000,0)
        
    def Attack(self, now):
        t = self.data["Attack"]["timeAttack"]
        super().Attack(now)
        if self.data["Attack"]["timeAttack"] != t:
            self.OnDisable()
    def Update(self, DT, runningTime):
        if self.deathPos.x == -1000:
            self.deathPos = pygame.Vector2(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
        if Function.Distance(self.pos, self.deathPos) <= 50:
            self.OnDisable()
        for i in range(random.randint(3,6)):
            self.SummonPTCs(6,self,random.randint(16,32),0,pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),0,0)
        super().Update(DT, runningTime)
    def OnDisable(self):
        for i in range(100):
                self.SummonPTCs(6,self,random.randint(32,48),random.randint(0,360),pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),5,2)
        
        return super().OnDisable()

class ParticalSpark(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Spark.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)
    
class ParticalGreen(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Green.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)
        self.particalPattern["Basic"]["lifeDuration"] = 0.05
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)

class ParticalGhost(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Ghost.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)

class ParticalBlood(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Blood.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)

class ParticalRed(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Red.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)
        self.particalPattern["Basic"]["lifeDuration"] = 0.05
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)

class ParticalSleep(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Sleeping.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)
        self.particalPattern["Basic"]["lifeDuration"] = 0.25
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)
        
class ParticalHeart(Particle):
    def __init__(self, image_file, screen, objList, particleList, SummonLocation, source, CPNisOpening=...):
        image_file = "IMAGE/MelodyTale_Particle_Heart.png"
        super().__init__(image_file, screen, objList, particleList, source, CPNisOpening)
        self.particalPattern["Basic"]["lifeDuration"] = 0.05
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)











ITEMDICT = {"item":{"Saber":Saber, "OakWoodBow":OakWoodBow, "Arrow0":Arrow0, "Harp":Harp}, "itemInfo":{"Saber":"A sharp blade", "Bow":"Shot targets in distant places", "Arrow0":"Just some Arrows"}}

allPrefabs = [Sheep, Saber, OakWoodBow]
CreaturePrefabs = [Sheep, Ghost]
TilePrefabs = [Rock,Tree_0_top,Tree_0_bot]
WeaponPrefabs = [Saber, OakWoodBow, Harp]
PickableItemPrefabs = [Saber]
BulletPrefabs = [Arrow0,Skill_1, Skill_2, Skill_3]
ParticlePrefabs = [ParticalSpark,ParticalGreen,ParticalGhost,ParticalBlood,ParticalRed,ParticalSleep,ParticalHeart]

class PrefabSummoner:
    def __init__(self, screen, objList, PTCList):
        self.screen = screen
        self.objList = objList
        self.PTCList = PTCList
    def SummonRandom(self):
        p = allPrefabs[random.randint(0,len(allPrefabs) - 1)]("", self.screen, self.objList, self.PTCList, pygame.Vector2(random.randint(100,900), random.randint(100,900)))
        self.objList.append(p)
        p.OnEnable()
    def SummonCreature(self, index, posx, posy):
        p = CreaturePrefabs[index]("", self.screen, self.objList, self.PTCList, pygame.Vector2(posx, posy))
        self.objList.append(p)
        p.OnEnable()
    def SummonWeapon(self, index, posx, posy):
        p = WeaponPrefabs[index]("", self.screen, self.objList, self.PTCList, pygame.Vector2(posx, posy))
        self.objList.append(p)
        p.OnEnable()
    def SummonTile(self, index, posx, posy):
        p = TilePrefabs[index]("", self.screen, self.objList, self.PTCList, pygame.Vector2(posx, posy))
        self.objList.append(p)
        p.OnEnable()
    def SummonBullet(self, index, pos, rotate):
        p = BulletPrefabs[index]("", self.screen, self.objList, self.PTCList, pos)
        self.objList.append(p)
        p.pos = pos
        p.data["SetImage"]["rotate"] = rotate
        p.OnEnable()

class PTCSummoner(GameObject):
    def __init__(self, image_file, screen, objList, particleList, CPNisOpening=[]):
        self.pos = pygame.Vector2(0,0)
        self.screen = screen
        self.objList = objList
        self.particleList = particleList
    def OnEnable(self, imageFileList=[]):
        pass
    def Update(self, DT, runningTime):
        pass
    def SummonPTCs(self, index, source, Tscale, Trotate, Tpos, Bscale, Brotate, Bpos):
        p = ParticlePrefabs[index]("", self.screen, self.objList, self.particleList, source.pos, source)
        p.particalPattern["Transform"]["scale"] = Tscale
        p.particalPattern["Transform"]["rotate"] = Trotate
        p.particalPattern["Transform"]["pos"] = Tpos
        p.particalPattern["Behavior"]["scale"] = Bscale
        p.particalPattern["Behavior"]["rotate"] = Brotate
        p.particalPattern["Behavior"]["move"] = Bpos
        self.particleList.append(p)
        p.OnEnable()