import pygame, pandas, openpyxl, importlib
import Prefab

class Secnery:
    def __init__(self, mapFile, screen, objList, particleList, bgBase, bgimg):
        self.mapFile = mapFile
        self.screen = screen
        self.objBuffer = []
        self.objList = objList
        self.particleList = particleList
        self.background = {"base":bgBase, "backgroundIMG":bgimg}
    def LoadScenery(self):
        r = 0
        c = 0
        T = Prefab.PrefabSummoner(self.screen,self.objList,self.particleList)
        with open("DATA/Map.txt","r") as f:
            for line in f:
                line=line.strip().split(',')
                for d in line:
                    d = int(d)
                    try:
                        T.SummonTile(d,c*100+1,r*100+1)
                    except:
                        pass
                    c += 1
                c = 0
                r += 1
    def UpdateScenery(self, dt, runningTime):
        self.background["base"].Update(dt, runningTime)
        for objs in self.objList:
            objs.Update(dt, runningTime)
        for PTCs in self.particleList:
            PTCs.Update(dt, runningTime)
