import pygame
BUFFLIST = {0:"Heal", 1:"Charm", 2:"Sleep"}
Image_files_for_UI = {"images":{"Saber":"Saber", "OakWoodBow":"OakWoodBow", "Arrow0":"Arrow0"}, "traits1":{"Saber":"Damage: 5","OakWoodBow":"Damage: 2"},"traits2":{"Saber":"Require level: Any", "OakWoodBow":"Require level: Any"}}
pygame.font.init()
fontUI_Title0 = pygame.font.Font(None, 36)
fontUI_Title1 = pygame.font.Font(None, 24)
fontUI_Text0 = pygame.font.Font(None, 18)
fontUI_Text1 = pygame.font.Font(None, 16)

class UI:
    def __init__(self, screen, mainCharacter):
        self.mainCharacter = mainCharacter
        self.screen = screen
    def DisplayUI(self):
        pass
class LifeDisplayer(UI):
    def __init__(self, screen, mainCharacter):
        super().__init__(screen, mainCharacter)
    def DisplayUI(self):
        for i in range(self.mainCharacter.data["Health"]["maxHealth"]):
            self.screen.screen.blit(pygame.image.load("IMAGE/MelodyTale_HeartFilled.png" if i < self.mainCharacter.data["Health"]["currentHealth"] else "IMAGE/MelodyTale_Heart.png").convert_alpha(), (10 + i * 32,50))

class BagUI(UI):
    def __init__(self, screen, mainCharacter):
        super().__init__(screen, mainCharacter)
        self.image1 = pygame.image.load("IMAGE/MelodyTale_BagUI1.png").convert_alpha()
        self.image2 = pygame.image.load("IMAGE/MelodyTale_BagUI2.png").convert_alpha()
        self.posx1 = -180
        self.posx2 = 1200
        self.cursor = None
        self.rectList = []
        self.equipmentRect = []
        self.focusedPoint = 24
        self.hasSummoned = False
        self.gridSummonpos = pygame.Vector2(948, 218)
    def DisplayUI(self, cursor):
        self.cursor = cursor
        if self.mainCharacter.bagOpening:
            self.mainCharacter.data["SetImage"]["using"] = 0
            self.mainCharacter.data["Animate"]["animationSpeed"] = .25
            self.screen.screen.blit(self.image1, (self.posx1,100))
            self.screen.screen.blit(self.image2, (self.posx2,100))
            if self.posx1 < 70 or self.posx2 > 900:
                if self.posx1 < 70:
                    self.posx1 += 10
                if self.posx2 > 900:
                    self.posx2 -= 10
            else:
                try:
                        self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_"+self.mainCharacter.equipment["weapon"]+".png").convert_alpha(),(64,64)),(71+32,243+40))
                        text0 = fontUI_Title0.render(self.mainCharacter.equipment["weapon"], False, (255, 255, 255))
                        text1 = fontUI_Title1.render(Image_files_for_UI["traits1"][self.mainCharacter.equipment["weapon"]], False, (255, 255, 255))
                        text2 = fontUI_Title1.render(Image_files_for_UI["traits2"][self.mainCharacter.equipment["weapon"]], False, (255,255,255))
                        self.screen.screen.blit(text0, text0.get_rect(topleft = (180,243+40)))
                        self.screen.screen.blit(text1, text1.get_rect(topleft = (180,243+70)))
                        self.screen.screen.blit(text2, text2.get_rect(topleft = (180,243+90)))
                except:
                    pass
                if not self.hasSummoned:
                    self.hasSummoned = True
                    self.ShowItemGrid()
                else:
                    
                    i = 0
                    for images in self.rectList:
                        try:
                            self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_"+Image_files_for_UI["images"][self.mainCharacter.bag[i]]+".png").convert_alpha(),(45,44)),(images.x,images.y))
                        except:
                            pass
                        i += 1
                    i = 0
                    mouse = pygame.mouse.get_pressed()
                    keys = pygame.key.get_pressed()
                    if keys[pygame.K_ESCAPE]:
                        self.focusedPoint = 24
                    for equipRect in self.equipmentRect:
                        if self.cursor.colliderect(equipRect):
                            if mouse[0]:
                                pass
                            else:
                                self.screen.screen.blit(pygame.image.load("IMAGE/MelodyTale_BagUI1_Grid.png").convert_alpha(),(equipRect.x, equipRect.y))
                                
                    
                    for rects in self.rectList:
                        if self.focusedPoint == 24:
                            if self.cursor.colliderect(rects):
                                if mouse[0]:
                                    if len(self.mainCharacter.bag) > i:
                                        self.focusedPoint = i
                                else:
                                    self.screen.screen.blit(pygame.image.load("IMAGE/MelodyTale_BagUI_Grid.png").convert_alpha(),(rects.x-4,rects.y-4))
                        elif self.focusedPoint == i:
                            if len(self.mainCharacter.bag) > i:
                                self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_BagItemInfo.png").convert_alpha(),(240, 148)),(rects.x-216,rects.y+24))
                                text0 = fontUI_Title0.render(self.mainCharacter.bag[i], False, (255, 255, 255))
                                text1 = fontUI_Title1.render(Image_files_for_UI["traits1"][self.mainCharacter.bag[i]], False, (255, 255, 255))
                                text2 = fontUI_Title1.render(Image_files_for_UI["traits2"][self.mainCharacter.bag[i]], False, (255,255,255))
                                text3 = fontUI_Text0.render("Equip", False, (0,0,0))
                                Button = pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_BagItemInfo_Button_Equip.png").convert_alpha(),(64,24))
                                self.screen.screen.blit(text0, text0.get_rect(topleft = (rects.x - 96 - text0.get_rect().w/2,rects.y+30)))
                                self.screen.screen.blit(text1, text1.get_rect(topleft = (rects.x - 200,rects.y+60)))
                                self.screen.screen.blit(text2, text2.get_rect(topleft = (rects.x - 200,rects.y+75)))
                                self.screen.screen.blit(Button, Button.get_rect(topleft = (rects.x - 96 - Button.get_rect().w/2,rects.y+130)))
                                self.screen.screen.blit(text3, text3.get_rect(topleft = (rects.x - 96 - text3.get_rect().w/2,rects.y+135)))
                                ButtonCollision = Button.get_rect(topleft = (rects.x - 96 - text3.get_rect().w/2,rects.y+135))
                                if mouse[0]:
                                    if ButtonCollision.colliderect(self.cursor):
                                        self.mainCharacter.bag[i], self.mainCharacter.equipment["weapon"] = self.mainCharacter.equipment["weapon"], self.mainCharacter.bag[i]
                                        if self.mainCharacter.bag[i] == "":
                                            self.mainCharacter.bag.remove("")
                                        # self.mainCharacter.objList.append()
                                        self.focusedPoint = 24
                        i += 1
        else:
            if self.posx1 > -180:
                self.posx1 -= 10
                self.screen.screen.blit(self.image1, (self.posx1,100))
            if self.posx2 < 1200:
                self.rectList = []
                self.focusedPoint = 24
                self.posx2 += 10
                self.screen.screen.blit(self.image2, (self.posx2,100))
                self.hasSummoned = False
                self.gridSummonpos = pygame.Vector2(948, 218)
    def ShowItemGrid(self):
        if len(self.rectList) < 24:
            for i in range(6):
                for p in range(4):
                    self.rectList.append(pygame.Rect(self.gridSummonpos.x + 4, self.gridSummonpos.y + 4, 45, 44))
                    self.gridSummonpos.x += 57
                self.gridSummonpos.x = 948
                self.gridSummonpos.y += 56
        self.equipmentRect.append(pygame.Rect(93, 265, 254, 99))
        self.equipmentRect.append(pygame.Rect(93, 405, 254, 99))
    def EquipCharacter():
        pass
    
class ExpStatus(UI):
    def __init__(self, screen, mainCharacter):
        super().__init__(screen, mainCharacter)
        self.length = 0
    def DisplayUI(self):
        if self.mainCharacter.exp/(self.mainCharacter.level*100) > self.length:
            self.length += 0.005
        self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_EnemyBloodLine.png").convert_alpha(),(1280,100)),(0,-47))
        self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_ExpLine.png").convert_alpha(),(1280 * self.length,100)),(0,-47))

class SkillUI(UI):
    def __init__(self, screen, mainCharacter):
        super().__init__(screen, mainCharacter)
        self.cursor = None
        self.rectList = [pygame.Rect(470 + 8, 616 + 8, 60, 60), pygame.Rect(546 + 8, 616 + 8, 60, 60), pygame.Rect(622 + 8, 616 + 8, 60, 60), pygame.Rect(698 + 8, 616 + 8, 60, 60)]
    def DisplayUI(self, cursor, now):
        if self.mainCharacter.CPNs["InputController"]:
            self.cursor = cursor
            self.screen.screen.blit(pygame.image.load("IMAGE/MelodyTale_SkillList.png").convert_alpha(),(456,600))
            self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_SkillLogo_1.png").convert_alpha(),(50,50)),(self.rectList[0].x,self.rectList[0].y))
            self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_SkillLogo_2.png").convert_alpha(),(55,55)),(self.rectList[1].x,self.rectList[1].y))
            self.screen.screen.blit(pygame.transform.scale(pygame.image.load("IMAGE/MelodyTale_SkillLogo_3.png").convert_alpha(),(50,50)),(self.rectList[2].x,self.rectList[2].y))
            mouse = pygame.mouse.get_pressed()
            for rects in self.rectList:
                if rects.colliderect(self.cursor):
                    if mouse[2]:
                        if self.rectList.index(rects) == 0 and (self.mainCharacter.skillCPN["skillUseTime"][0] < 0 or now - self.mainCharacter.skillCPN["skillUseTime"][0] > self.mainCharacter.skillCPN["skillCooldownTime"][0] * 1000):
                            self.mainCharacter.skillCPN["currentSkill"] = 1
                            self.mainCharacter.equipment["weapon"] = "Harp";
                        if self.rectList.index(rects) == 1 and (self.mainCharacter.skillCPN["skillUseTime"][1] < 0 or now - self.mainCharacter.skillCPN["skillUseTime"][1] > self.mainCharacter.skillCPN["skillCooldownTime"][1] * 1000):
                            self.mainCharacter.skillCPN["currentSkill"] = 2
                            self.mainCharacter.equipment["weapon"] = "Harp";
                        if self.rectList.index(rects) == 2 and (self.mainCharacter.skillCPN["skillUseTime"][2] < 0 or now - self.mainCharacter.skillCPN["skillUseTime"][1] > self.mainCharacter.skillCPN["skillCooldownTime"][2] * 1000):
                            self.mainCharacter.skillCPN["currentSkill"] = 3
                            self.mainCharacter.equipment["weapon"] = "Harp";
                    else:
                        self.screen.screen.blit(pygame.image.load("IMAGE/MelodyTale_skillList_Grid.png").convert_alpha(),(rects.x - 8, rects.y - 8))
        