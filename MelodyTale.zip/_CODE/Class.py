import pygame,random,math,sys
from Function import RateAct, Distance
from UI import BagUI

class Screen:
    def __init__(self, Width, Height):
        self.WIDTH = Width
        self.HEIGHT = Height
        self.screen = None
    def CreateScreen(self):
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        return pygame.display.set_mode((self.WIDTH, self.HEIGHT))
class GameObject:
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening = []):
        self.objList = objList
        self.PTCList = PTCList
        self.screen = screen
        self.image = pygame.image.load(image_file).convert_alpha()
        self.pos = pygame.Vector2(0, 0)
        self.mainCharacterDir = pygame.Vector2(0,0)
        self.CPNs = {"SetImage":False, "Collision":False, "Barrier":False, "Move":False, "Animate":False, "Attack":False, "Health":False, "InputController":False, "Item":False}
        self.data = {"SetImage":{"imageFiles":[], "using":0, "displaying":0, "showingPart":pygame.Rect(0, 0, 32, 32), "scale":{"x":100, "y":100}, "rotate":0, "flip":{"x":False, "y":False}, "color":(0, 0, 0, 0), "isDisplay":True, "flickSpeed":.5}, "Anchor":{"position":pygame.Vector2(0,0),"rotate":0, "ext":[pygame.Vector2(0,0)]}, "Collision":{"rect":pygame.Rect(self.pos.x, self.pos.y, 100, 100)}, "Barrier":{"barrierAble":True}, "Move":{"moveDir":pygame.Vector2(0, 0), "moveSpeed":300}, "Animate":{"animationSpeed":0.25}, "Attack":{"damage":1, "timeAttack":0}, "Health":{"maxHealth":3, "currentHealth": 3, "hurtCoolDown":1, "camp":0, "damageSource":None, "timeGetHurt":0, "ableToFlick":True, "bloodDisplay":True}, "Parent":None, "Child":{"obj":[],"using":0}, "InputController":{"mousePos":pygame.Vector2(0,0)}, "Item":{"pickable":True}}
        
        self.data["Health"]["currentHealth"] = self.data["Health"]["maxHealth"]
        if CPNisOpening != []:
            self.CPNs["SetImage"] = CPNisOpening[0]
            self.CPNs["Collision"] = CPNisOpening[1]
            self.CPNs["Barrier"] = CPNisOpening[2]
            self.CPNs["Move"] = CPNisOpening[3]
            self.CPNs["Animate"] = CPNisOpening[4]
            self.CPNs["Attack"] = CPNisOpening[5]
            self.CPNs["Health"] = CPNisOpening[6]
            self.CPNs["InputController"] = CPNisOpening[7]
            self.CPNs["Item"] = CPNisOpening[8]
    def ImageListInitializer(self, filePathList = []):
        if self.CPNs["SetImage"]:
            
            frames = []
            for i in range(len(filePathList)):
                f = []
                for p in range(int(pygame.image.load(filePathList[i]).get_rect().w / 32)):
                    self.data["SetImage"]["showingPart"] = pygame.Rect(p * 32, 0, 32, 32)
                    f.append(pygame.image.load(filePathList[i]).convert_alpha().subsurface(self.data["SetImage"]["showingPart"]))
                frames.append(f)
            self.data["SetImage"]["imageFiles"] = frames
    def SetImage(self):
        if self.CPNs["SetImage"]:
            if self.data["SetImage"]["isDisplay"]:
                if self.data["Parent"] == None:
                    self.screen.screen.blit(pygame.transform.rotate(pygame.transform.flip(pygame.transform.scale(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]][int(self.data["SetImage"]["displaying"]//(1/self.data["Animate"]["animationSpeed"]))], (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])), self.data["SetImage"]["flip"]["x"], self.data["SetImage"]["flip"]["y"]),self.data["SetImage"]["rotate"]), self.pos)
                    self.data["Collision"]["rect"] = pygame.Rect(self.pos.x, self.pos.y, 100, 100)
                else:
                    try:
                        self.screen.screen.blit(pygame.transform.rotate(pygame.transform.flip(pygame.transform.scale(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]][int(self.data["SetImage"]["displaying"]//(1/self.data["Animate"]["animationSpeed"]))], (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])),self.data["Parent"].data["SetImage"]["flip"]["x"],self.data["Parent"].data["SetImage"]["flip"]["y"]),self.data["SetImage"]["rotate"] + self.data["Parent"].data["SetImage"]["rotate"] - self.data["Parent"].data["Anchor"]["rotate"] + (180 if self.data["Parent"].data["SetImage"]["flip"]["x"] else 0)),(self.data["Parent"].pos) + pygame.Vector2(math.cos(math.radians(self.data["Parent"].data["Anchor"]["rotate"])),math.sin(math.radians(self.data["Parent"].data["Anchor"]["rotate"]))) * (self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].x) + pygame.Vector2(0, self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].y))
                        q = pygame.Vector2(self.data["Parent"].pos) + pygame.Vector2(math.cos(math.radians(self.data["Parent"].data["Anchor"]["rotate"])),math.sin(math.radians(self.data["Parent"].data["Anchor"]["rotate"]))) * (self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].x) + pygame.Vector2(0, self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].y)
                        self.data["Collision"]["rect"] = pygame.Rect( q.x,q.y, 100, 100)
                    except:
                        pass
        else:
            if self.data["SetImage"]["isDisplay"]:
                if self.data["Parent"] == None:
                    self.screen.screen.blit(pygame.transform.rotate(pygame.transform.flip(pygame.transform.scale(self.image, (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])), self.data["SetImage"]["flip"]["x"], self.data["SetImage"]["flip"]["y"]),self.data["SetImage"]["rotate"]), self.pos)
                    self.data["Collision"]["rect"] = pygame.Rect(self.pos.x, self.pos.y, 100, 100)
                else:
                    try:
                        self.screen.screen.blit(pygame.transform.rotate(pygame.transform.flip(pygame.transform.scale(self.image, (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])),self.data["Parent"].data["SetImage"]["flip"]["x"],self.data["Parent"].data["SetImage"]["flip"]["y"]),self.data["SetImage"]["rotate"] + self.data["Parent"].data["SetImage"]["rotate"] - self.data["Parent"].data["Anchor"]["rotate"] + (180 if self.data["Parent"].data["SetImage"]["flip"]["x"] else 0)),(self.data["Parent"].pos) + pygame.Vector2(math.cos(math.radians(self.data["Parent"].data["Anchor"]["rotate"])),math.sin(math.radians(self.data["Parent"].data["Anchor"]["rotate"]))) * (self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].x) + pygame.Vector2(0, self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].y))
                        q = pygame.Vector2(self.data["Parent"].pos) + pygame.Vector2(math.cos(math.radians(self.data["Parent"].data["Anchor"]["rotate"])),math.sin(math.radians(self.data["Parent"].data["Anchor"]["rotate"]))) * (self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].x) + pygame.Vector2(0, self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].y)
                        self.data["Collision"]["rect"] = pygame.Rect( q.x,q.y, 100, 100) 
                    except:
                        pass
    def Move(self):
        if self.CPNs["Move"]:
            pass
    def AnimateOneFrame(self):
        if self.CPNs["SetImage"] and self.CPNs["Animate"]:
            self.data["SetImage"]["displaying"] += 1
            self.data["SetImage"]["displaying"] %= int(len(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]]) * (1 / self.data["Animate"]["animationSpeed"]))
    def Attack(self, now):
        if self.CPNs["Collision"] and self.CPNs["Attack"]:
            for objs in self.objList:
                try:
                    if objs.CPNs["Health"]:
                        if objs.CPNs["Collision"] and self.data["Collision"]["rect"].colliderect(objs.data["Collision"]["rect"]) and objs != self:
                            if self.data["Health"]["camp"] != objs.data["Health"]["camp"] and now - objs.data["Health"]["timeGetHurt"] > objs.data["Health"]["hurtCoolDown"] * 1000:
                                objs.data["Health"]["damageSource"] = self
                                objs.data["Health"]["timeGetHurt"] = now
                                self.data["Attack"]["timeAttack"] = now
                                objs.data["Health"]["currentHealth"] -= self.data["Attack"]["damage"]
                except:
                    pass
    def Health(self, now):
        if self.CPNs["Health"]:
            if self.data["Health"]["currentHealth"] < self.data["Health"]["maxHealth"]:
                if self.data["Health"]["ableToFlick"]:
                    if not self.data["SetImage"]["isDisplay"]:
                        self.data["SetImage"]["isDisplay"] = True
                    else:
                        if now - self.data["Health"]["timeGetHurt"] <= 1000 * self.data["Health"]["hurtCoolDown"] and now % (1/self.data["SetImage"]["flickSpeed"]) == 0:
                            self.data["SetImage"]["isDisplay"] = False
                if self.data["Health"]["bloodDisplay"] and now - self.data["Health"]["timeGetHurt"] <= 1000 * self.data["Health"]["hurtCoolDown"]:
                    for i in range(1,2):
                        self.SummonPTCs(3,self,random.randint(50,75),0,pygame.Vector2(random.randint(-25,25), random.randint(-25,25)),0,0,0)
            if self.data["Health"]["currentHealth"] <= 0:
                self.OnDisable()
    def SummonPTCs(self, index, source, Tscale, Trotate, Tpos, Bscale, Brotate, Bpos):
        for objs in self.objList:
            if type(objs).__name__ == "PTCSummoner":
                objs.SummonPTCs(index, source, Tscale, Trotate, Tpos, Bscale, Brotate, Bpos)
    def OnEnable(self, imageFileList = []):
        i = 0
        for child in self.data["Child"]["obj"]:
            c = child("", self.screen, self.objList, self.PTCList, self.pos.copy())
            self.objList.append(c)
            c.data["Parent"] = self
            self.data["Child"]["obj"][i] = c
            c.data["Child"]["using"] = i
            i += 1
        self.ImageListInitializer(imageFileList)
        if self.data["Parent"] == None:
            
            self.screen.screen.blit(pygame.transform.rotate(pygame.transform.flip(pygame.transform.scale(self.image, (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])), self.data["SetImage"]["flip"]["x"], self.data["SetImage"]["flip"]["y"]),self.data["SetImage"]["rotate"]),(self.pos))
        else:
            self.screen.screen.blit(pygame.transform.rotate(pygame.transform.flip(pygame.transform.scale(self.image, (self.data["SetImage"]["scale"]["x"], self.data["SetImage"]["scale"]["y"])),self.data["Parent"].data["SetImage"]["flip"]["x"],self.data["Parent"].data["SetImage"]["flip"]["y"]),self.data["SetImage"]["rotate"] + self.data["Parent"].data["SetImage"]["rotate"] - self.data["Parent"].data["Anchor"]["rotate"] + (180 if self.data["Parent"].data["SetImage"]["flip"]["x"] else 0)),(self.data["Parent"].pos) + pygame.Vector2(math.cos(math.radians(self.data["Parent"].data["Anchor"]["rotate"])),math.sin(math.radians(self.data["Parent"].data["Anchor"]["rotate"]))) * (self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].x) + pygame.Vector2(0, self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].y))
            q = (self.data["Parent"].pos) + pygame.Vector2(math.cos(math.radians(self.data["Parent"].data["Anchor"]["rotate"])),math.sin(math.radians(self.data["Parent"].data["Anchor"]["rotate"]))) * (self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].x) + pygame.Vector2(0, self.data["Parent"].data["Anchor"]["ext"][self.data["Child"]["using"]].y)
            self.data["Collision"]["rect"] = pygame.Rect( q.x,q.y, 100, 100)
    def Awake(self):
        for child in self.data["Child"]["obj"]:
            pass
    def Start(self):
        pass
    def Update(self, DT,runningTime):
        self.data["Anchor"]["position"] = pygame.Vector2(self.data["Collision"]["rect"].x, self.data["Collision"]["rect"].y)
        self.pos += self.data["Move"]["moveDir"] * self.data["Move"]["moveSpeed"] * DT
        if self.data["Parent"] == None:
            for objs in self.objList:
                if issubclass(objs.__class__, Player):
                    self.pos += self.mainCharacterDir * objs.data["Move"]["moveSpeed"] * DT
                    break
            self.mainCharacterDir = pygame.Vector2(0,0)
        else:
            self.pos = self.data["Parent"].pos.copy()
        self.SetImage()
    def OnDisable(self):
        if self.CPNs["SetImage"] and self.CPNs["Animate"]:
            self.data["Animate"]["AnimationSpeed"] = 0.02
            if len(self.data["SetImage"]["imageFiles"]) >= 3:
                self.data["SetImage"]["using"] = 2
            if self.data["SetImage"]["displaying"] >= int((len(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]]) * (1 / self.data["Animate"]["animationSpeed"])) - 1)/2 + 1:
                self.CPNs["Animate"] = False
        else:
            pass
        try:
            self.objList.remove(self)
            for child in self.data["Child"]["obj"]:
                if child in self.objList:
                    child.OnDisable()
        except:
            pass
class Background(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        
    def Update(self, DT, runningTime):
        self.data["Collision"]["rect"].x = self.pos.x
        self.data["Collision"]["rect"].y = self.pos.y
        return super().Update(DT,runningTime)
        
class Creature(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.data["SetImage"]["scale"]["x"] = 100
        self.data["SetImage"]["scale"]["y"] = 100
        self.camp_buffer = 1
        self.BuffCPN = {"buffAble":True, "buffList":[], "buffEffectTime":[], "buffMargin":[], "buffDeadTime":[]}
    def Buff(self, now):
        
        try:
            for buff in range(len(self.BuffCPN["buffList"])):
                if self.BuffCPN["buffDeadTime"][buff] <= self.BuffCPN["buffEffectTime"][buff]:
                    # print(self.camp_buffer)
                    if self.BuffCPN["buffList"][buff] == 1:
                        self.CPNs["Attack"] = True
                        self.CPNs["Move"] = True
                    if self.BuffCPN["buffList"][buff] == 2:
                        self.data["Health"]["camp"] = self.camp_buffer
                        
                    del self.BuffCPN["buffList"][buff]
                    del self.BuffCPN["buffEffectTime"][buff]
                    del self.BuffCPN["buffMargin"][buff]
                    del self.BuffCPN["buffDeadTime"][buff]
                else:
                    if self.BuffCPN["buffList"][buff] == 0:
                        self.SummonPTCs(1,self,random.randint(16,32),random.randint(0,360),pygame.Vector2(random.randint(-100,100), random.randint(-100,100)),random.randint(300, 700),5,0)
                        if self.BuffCPN["buffEffectTime"][buff] < 0 or now - self.BuffCPN["buffEffectTime"][buff] > 1000 * self.BuffCPN["buffMargin"][buff]:
                            if self.CPNs["Health"]:
                                self.BuffCPN["buffEffectTime"][buff] = now
                                self.data["Health"]["currentHealth"] += 1 if self.data["Health"]["currentHealth"] < self.data["Health"]["maxHealth"] else 0
                    elif self.BuffCPN["buffList"][buff] == 1:
                        self.BuffCPN["buffEffectTime"][buff] = now
                        if RateAct(20):
                            self.SummonPTCs(5,self,random.randint(32,48),0,pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),0,0)
                        self.CPNs["Attack"] = False
                        self.CPNs["Move"] = False
                    elif self.BuffCPN["buffList"][buff] == 2:
                        self.BuffCPN["buffEffectTime"][buff] = now
                        if RateAct(20):
                            self.SummonPTCs(6,self,random.randint(32,48),0,pygame.Vector2(random.randint(-50,50), random.randint(-50,50)),random.randint(300, 700),0,0)
                        self.data["Health"]["camp"] = 0
        except:
            pass
                    
                    
    def Update(self, DT, runningTime):
        self.Buff(runningTime)
        return super().Update(DT, runningTime)
class Player(Creature):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.bagOpening = False
        self.lastpressTime = 0
        self.level = 1
        self.exp = 0
    def OnEnable(self, imageFileList=[]):
        self.pos.x = self.screen.WIDTH / 2 - 32
        self.pos.y = self.screen.HEIGHT / 2 - 32
        self.data["Attack"]["damage"] = 1
        super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        self.data["Anchor"]["rotate"] = math.degrees(math.atan2(self.data["InputController"]["mousePos"].y - self.screen.HEIGHT/2,self.data["InputController"]["mousePos"].x - self.screen.WIDTH/2))
        if self.exp >= self.level * 100:
            self.exp -= self.level * 100
            self.level += 1
            self.data["Health"]["maxHealth"] += 1
            self.data["Health"]["currentHealth"] = self.data["Health"]["maxHealth"]
        self.Move(DT)
        self.Attack(runningTime)
        self.AnimateOneFrame()
        self.Health(runningTime)
        self.PickItem()
        self.QuitItem()
        if runningTime - self.lastpressTime >= 100:
            self.lastpressTime = runningTime
            self.ShowBag()
        super().Update(DT, runningTime)
    
    
    def ShowBag(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_i]:
            self.CPNs["InputController"] = not self.CPNs["InputController"]
            self.bagOpening = not self.bagOpening
            return None
    def Move(self, DeltaTime):
        if self.CPNs["Move"] and self.CPNs["InputController"]:
            self.data["Animate"]["animationSpeed"] = .25
            keys = pygame.key.get_pressed()
            if keys[pygame.K_w]:
                self.data["Move"]["moveDir"].y = 1
            if keys[pygame.K_s]:
                self.data["Move"]["moveDir"].y = -1
            if keys[pygame.K_a]:
                self.data["Move"]["moveDir"].x = 1
            if keys[pygame.K_d]:
                self.data["Move"]["moveDir"].x = -1
            if self.data["Move"]["moveDir"].x > 0:
                self.data["SetImage"]["flip"]["x"] = True
            elif self.data["Move"]["moveDir"].x < 0:
                self.data["SetImage"]["flip"]["x"] = False
            if ((self.data["Move"]["moveDir"].x ** 2 + self.data["Move"]["moveDir"].y ** 2) ** .5) != 0:
                if keys[pygame.K_LSHIFT]:
                    self.data["Move"]["moveSpeed"] = 600
                    self.data["Animate"]["animationSpeed"] = 1
                else:
                    self.data["Move"]["moveSpeed"] = 300
                    self.data["Animate"]["animationSpeed"] = .25
            if ((self.data["Move"]["moveDir"].x ** 2 + self.data["Move"]["moveDir"].y ** 2) ** .5) != 0:
                self.data["SetImage"]["using"] = 1
                for objs in self.objList:
                    try:
                        if objs.data["Parent"] == None and objs != self:
                            objs.mainCharacterDir = self.data["Move"]["moveDir"] / ((self.data["Move"]["moveDir"].x ** 2 + self.data["Move"]["moveDir"].y ** 2) ** .5)
                    except:
                        pass
            else:
                self.data["SetImage"]["using"] = 0
            self.data["Move"]["moveDir"].x = 0
            self.data["Move"]["moveDir"].y = 0
class Animal(Creature):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
    def OnEnable(self, imageFileList=[]):
        
        super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        super().Update(DT, runningTime)
        self.Move(DT)
        self.Attack(runningTime)
        self.Health(runningTime)
    def Move(self, DeltaTime):
        if self.CPNs["Move"]:
            if ((self.data["Move"]["moveDir"].x ** 2 + self.data["Move"]["moveDir"].y ** 2) ** .5) != 0:
                self.data["Move"]["moveDir"] = self.data["Move"]["moveDir"] if RateAct(90) else pygame.Vector2(0,0)
            else:
                if RateAct(10):
                    self.data["Move"]["moveDir"] = pygame.Vector2(random.randint(-1, 1), random.randint(-1, 1))
class Weapon(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.coolDownTime = 1000
    def OnEnable(self, imageFileList=[]):
        return super().OnEnable(imageFileList)
    def Update(self, DT, runningTime):
        if self.CPNs["SetImage"]:
            if self.data["SetImage"]["displaying"] == int(len(self.data["SetImage"]["imageFiles"][self.data["SetImage"]["using"]]) * (1 / self.data["Animate"]["animationSpeed"])) - 1:
                self.data["SetImage"]["using"] = 0
        self.AnimateOneFrame()
        if self.data["Parent"] != None and issubclass(self.data["Parent"].__class__, Player) and self.data["Parent"].CPNs["InputController"]:
            if issubclass(self.data["Parent"].__class__, Player):
                self.data["Parent"].data["InputController"]["mousePos"] = pygame.Vector2(pygame.mouse.get_pos()[0],pygame.mouse.get_pos()[1])
                if pygame.mouse.get_pressed()[0]:
                    if runningTime - self.data["Attack"]["timeAttack"] > self.coolDownTime:
                        self.data["Attack"]["timeAttack"] = runningTime
                        self.Attack(runningTime)
        return super().Update(DT, runningTime)
class MeleeWeapon(Weapon):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
    def Attack(self, now):
        self.data["SetImage"]["using"] = 1
        return super().Attack(now)
    def Update(self, DT, runningTime):
        return super().Update(DT, runningTime)
class DistantWeapon(Weapon):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        self.bullet = None
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
    def Attack(self, now):
        self.data["SetImage"]["using"] = 1
        return super().Attack(now)
    def Update(self, DT, runningTime):
        return super().Update(DT, runningTime)

class Bullet(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.startTime = -1
        self.LifeDur = 250
    def Update(self, DT, runningTime):
        if self.startTime < 0:
            self.startTime = runningTime
        else:
            if runningTime - self.startTime >= self.LifeDur:
                self.OnDisable()
        self.pos -= pygame.Vector2(-1*math.cos(math.radians(self.data["SetImage"]["rotate"])), math.sin(math.radians(self.data["SetImage"]["rotate"]))) * self.data["Move"]["moveSpeed"] * DT
        self.Attack(runningTime)
        super().Update(DT, runningTime)

class Skill(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
        self.startTime = -1
        self.LifeDur = 250
        self.Area = 100
        self.SetBuffCPN = {"buffCode":0, "buffMargin":3, "buffLifeTime":10}
    def SetBuff(self, now):
        if self.CPNs["Collision"]:
            for objs in self.objList:
                if issubclass(objs.__class__, Creature):
                    try:
                        if Distance(self.pos, objs.pos) < self.Area and objs != self and objs.BuffCPN["buffAble"]:
                            if ((self.data["Health"]["camp"] == objs.data["Health"]["camp"]) and (self.SetBuffCPN["buffCode"] == 0)) or ((self.data["Health"]["camp"] != objs.data["Health"]["camp"]) and (self.SetBuffCPN["buffCode"] == 1 or self.SetBuffCPN["buffCode"] == 2)):
                                if self.SetBuffCPN["buffCode"] not in objs.BuffCPN["buffList"]:
                                    objs.BuffCPN["buffList"].append(self.SetBuffCPN["buffCode"])
                                    objs.BuffCPN["buffEffectTime"].append(-1)
                                    objs.BuffCPN["buffMargin"].append(self.SetBuffCPN["buffMargin"])
                                    objs.BuffCPN["buffDeadTime"].append(now + self.SetBuffCPN["buffLifeTime"] * 1000)
                                
                    except:
                        pass
    def Update(self, DT, runningTime):
        if self.startTime < 0:
            self.startTime = runningTime
        else:
            if runningTime - self.startTime >= self.LifeDur:
                self.OnDisable()
        self.pos -= pygame.Vector2(-1*math.cos(math.radians(self.data["SetImage"]["rotate"])), math.sin(math.radians(self.data["SetImage"]["rotate"]))) * self.data["Move"]["moveSpeed"] * DT
        self.SetBuff(runningTime)
        super().Update(DT, runningTime)

class Tile(GameObject):
    def __init__(self, image_file, screen, objList, PTCList, CPNisOpening=[]):
        super().__init__(image_file, screen, objList, PTCList, CPNisOpening)
    def Update(self, DT, runningTime):
        if self.data["Barrier"]["barrierAble"]:
            if self.CPNs["Barrier"] and self.CPNs["Collision"]:
                for objs in self.objList:
                    if issubclass(objs.__class__, Player):
                        pass
                    try:
                        if pygame.Rect(self.data["Collision"]["rect"].x, self.data["Collision"]["rect"].y + 50, self.data["Collision"]["rect"].w, self.data["Collision"]["rect"].h - 50).colliderect(objs.data["Collision"]["rect"] if not issubclass(objs.__class__, Creature) else pygame.Rect(objs.data["Collision"]["rect"].x,objs.data["Collision"]["rect"].y + 50, objs.data["Collision"]["rect"].w, objs.data["Collision"]["rect"].h - 50)) and objs != self and objs.CPNs["Move"]:
                            if not issubclass(objs.__class__, Player):
                                objs.pos.x += objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                objs.pos.y += objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                            else:
                                self.image.copy().fill((255,255,255,255))
                                for o in self.objList:
                                    if objs != o:
                                        if abs(self.pos.x - objs.pos.x) >= 50:
                                            o.pos.x -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                        if abs(self.pos.y - objs.pos.y) >= 25:
                                            o.pos.y -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                                for o in self.PTCList:
                                    if objs != o:
                                        if abs(self.pos.x - objs.pos.x) >= 50:
                                            o.particalPattern["Transform"]["pos"].x -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.x < objs.pos.x else -1)
                                        if abs(self.pos.y - objs.pos.y) >= 25:
                                            o.particalPattern["Transform"]["pos"].y -= objs.data["Move"]["moveSpeed"] * DT * (1 if self.pos.y < objs.pos.y else -1)
                    except:
                        pass
        return super().Update(DT, runningTime)
    
class Particle(GameObject):
    def __init__(self, image_file, screen, objList, particleList, source, CPNisOpening=[]):
        self.image = pygame.image.load(image_file).convert_alpha()
        self.mainCharacterDir = pygame.Vector2(0,0)
        self.screen = screen
        self.objList = objList
        self.particalList = particleList
        self.source = source
        self.summonTime = -1
        self.sourcePos = self.source.pos.copy()
        self.particalPattern = {"Basic":{"centralPos":self.source.pos, "lifeDuration":(1,3), "deathPattern":1},
                                "Transform":{"scale":16, "rotate":0, "pos":pygame.Vector2(random.randint(0,100),0)},
                                "Behavior":{"scale":1, "rotate":0, "move":1}
                                }
        # Lifeduration can be an int or a float or a tuple,
        # Deathpattern 0->instant 1->shrink
        # Behavior /scale: 0->solid 1->variable(SPEED)/ /move: 0->randomly 1->solid 2->shoot/
        self.SCALE = None
        self.ROTATE = None
        
        
        
    def OnEnable(self, imageFileList=[]):
        self.SCALE = self.particalPattern["Transform"]["scale"]
        self.ROTATE = self.particalPattern["Transform"]["rotate"]
        self.screen.screen.blit(self.image, pygame.Vector2(-1000,-1000))
    def Update(self, DT, runningTime):
        try:
            self.mainCharacterDir = self.objList[0].mainCharacterDir
        except:
            self.mainCharacterDir = self.objList[1].mainCharacterDir
        if self.particalPattern["Behavior"]["move"] == 2 and ((self.particalPattern["Transform"]["pos"].x**2 + self.particalPattern["Transform"]["pos"].y**2)**.5) != 0:
            self.particalPattern["Transform"]["pos"] += self.particalPattern["Transform"]["pos"]/ ((self.particalPattern["Transform"]["pos"].x**2 + self.particalPattern["Transform"]["pos"].y**2)**.5) * DT * 300
        self.particalPattern["Basic"]["centralPos"] = self.sourcePos + pygame.Vector2(45,45) + .65*pygame.Vector2(self.SCALE - self.particalPattern["Transform"]["scale"], self.SCALE - self.particalPattern["Transform"]["scale"]) + self.particalPattern["Transform"]["pos"]
        
        
        self.screen.screen.blit(pygame.transform.rotate(pygame.transform.scale(self.image, (self.particalPattern["Transform"]["scale"],self.particalPattern["Transform"]["scale"])), self.particalPattern["Transform"]["rotate"]), (self.particalPattern["Basic"]["centralPos"].x, self.particalPattern["Basic"]["centralPos"].y))
        self.particalPattern["Transform"]["rotate"] += self.particalPattern["Behavior"]["rotate"]
        for objs in self.objList:
            if issubclass(objs.__class__, Player):
                self.particalPattern["Transform"]["pos"] += self.mainCharacterDir * objs.data["Move"]["moveSpeed"] * DT
                break
        self.mainCharacterDir = pygame.Vector2(0,0)
        if self.summonTime == -1:
            self.summonTime = runningTime
        else:
            if type(self.particalPattern["Basic"]["lifeDuration"]) == tuple:
                self.particalPattern["Basic"]["lifeDuration"] = (random.random() + random.randint(self.particalPattern["Basic"]["lifeDuration"][0], self.particalPattern["Basic"]["lifeDuration"][1]))
                
            else:
                if runningTime - self.summonTime >= self.particalPattern["Basic"]["lifeDuration"] * 1000:
                    self.OnDisable()
                else:
                    if self.particalPattern["Behavior"]["scale"] > 0:
                        self.particalPattern["Transform"]["scale"] = abs(math.sin((runningTime/self.particalPattern["Behavior"]["scale"]))) * self.SCALE
    def OnDisable(self):
        if self.particalPattern["Basic"]["deathPattern"] == 1 and self.particalPattern["Transform"]["scale"] > 1:
            
            self.particalPattern["Transform"]["scale"] -= 1
        else:
            self.particalList.remove(self)
        
        